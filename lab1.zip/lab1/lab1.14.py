import math
class circle:
    def __init__(self, radius):
        self.radius= radius
    
    def area(radius):
        area= math.pi*radius*radius
        print("The area is: ", area)

    def perimeter(radius):
        permimeter= 2*math.pi*radius
        print("The permiter is: ", permimeter)

rad= float(input("Enter radius: "))
circle.area(rad)
circle.perimeter(rad)        