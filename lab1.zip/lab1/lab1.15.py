from datetime import date
class person:
    def __init__(self, name, country, dob):
        self.name= name
        self.country= country
        self.dob= dob

    def age(self, dob):
        today= date.today()
        newdob= int(dob[-4:])
        age= today.year- newdob
        return age

    def printFun(self, name, country, dob):
        ages= self.age(dob)
        print(f"The name of the person is {name}, country is {country} and the date of birth is {dob}.")
        print(f"The age is {ages}")
        

print("Enter name, country and date of birth(dd/mm/yyyy)")
name= input("Name: ")
country= input("Country: ")
dob= input("Date of Birth: ")
person1= person(name, country, dob)
person1.printFun(name, country, dob)