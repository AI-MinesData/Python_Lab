num=[]
for i in range(10):
    num.append(input(f"Enter {i+1}th student's marks: "))

for i in num:
    print(i)
