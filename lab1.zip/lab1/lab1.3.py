def calcu(num1, num2):
    
    sum= num1+num2
    diff= num1-num2
    mult= num1*num2
    div= num1/num2

    return sum, diff, mult, div

num1= float(input("Enter first number: "))
num2= float(input("Enter second number: "))

sums, diff, mult, div= calcu(num1, num2)
print(f"{num1} + {num2} = {sums}")
print(f"{num1} - {num2} = {diff}")
print(f"{num1} * {num2} = {mult}")
print(f"{num1} / {num2} = {div}")