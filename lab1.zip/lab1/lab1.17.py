#Create a class BankAccount with private attributes balance and account_number.
#Implement methods deposit() and withdraw() to modify the balance. Ensure that the
#balance cannot be accessed directly from outside the class.

class BankAccount:
    def __init__(self, balance, account_number):
        self.__balance= balance
        self.account_number= account_number
    def get_balance(self):
        return self.__balance
   
    def deposit(self, deposit):
        self.__balance+=deposit

    def withdraw(self, withdraw):
        if self.__balance>=withdraw:
            self.__balance-=withdraw

acc1= BankAccount(1000, 87809878)

deposit= int(input("Enter the amount you wish to deposit: "))
acc1.deposit(deposit)
print(f"The current amount in account is {acc1.get_balance()}")

withdraw= int(input("Enter the amount you wish to withdraw: "))
acc1.withdraw(withdraw)
print(f"The current amount in account is {acc1.get_balance()}")
