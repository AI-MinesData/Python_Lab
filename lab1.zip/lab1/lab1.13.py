def swap_case(s):
    swapped=[]

    for char in s:
        if char.isupper():
            swapped.append(char.lower())
        elif char.islower():
            swapped.append(char.upper())
        else:
            swapped.append(char)
    return ''.join(swapped)

string= input("Enter a string:  ")
print("The initial string: ", string)
print("The swapped string: ", swap_case(string))