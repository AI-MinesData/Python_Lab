num= int(input("Enter a number: "))
factorial=num
for i in range(1, num):
    factorial*=i

print("The factorial is ", factorial)