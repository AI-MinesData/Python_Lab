perc= int(input("Enter the percentage: "))

if perc>=80 and perc<=100:
    print("You scored distinction")
elif perc>=65 and perc<80:
    print("You scored first division")
elif perc>=55 and perc<65:
    print("You scored second division")
elif perc>=40 and perc<55:
    print("You scored third division")
elif perc<40 and perc>=0:
    print("You are fail")
else:
    print("Invalid percentage input")