numbers=[3,5,20,6,8]
largest= numbers[0]

for i in numbers:
    if i>=largest:
        largest=i
print(f"The largest number is {largest}")