sentencce= input("Enter any sentence: ")
count= 0
for i in sentencce:
    if i==' ':
        count+=1

print(f"The number of words are {count+1}")