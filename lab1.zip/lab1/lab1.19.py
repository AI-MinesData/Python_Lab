#Define classes Engine, Wheel, and Car. Engine and Wheel classes have attributes type and
#methods start() and stop(). The Car class should have instances of Engine and Wheel classes
#as attributes. Implement a method start_car() in the Car class which starts the engine and prints
#"Car started".

class Engine:
    def __init__(self, type):
        self.type= type
    
    def start(self):
        print("Engine started. ")
    def stop(self):
        print("Engine stopped. ")

class Wheel:
    def __init__(self, type):
        self.type= type
    
    def start(self):
        print("Wheel started. ")
    def stop(self):
        print("Wheel stopped. ")

class Car(Engine, Wheel):

    def __init__(self, engine, wheel):
        self.engine= Engine(engine)
        self.wheel= Wheel(wheel)

    def start_car(self):
        self.engine.start()
        self.wheel.start()
        print("Car started. ")



c1= Car("Engine1", "Wheel1")
c1.start_car()