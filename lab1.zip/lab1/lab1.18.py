#Implement a class Shape with a method area() which returns 0. Then, create subclasses
#Rectangle and Circle. Overload the area() method in both subclasses to calculate and return
#the area of a rectangle and a circle respectively.

import math

class Shape:
    
    
    def area(self):
        return 0

class Rectangle(Shape):
    def __init__(self, length, breadth):
        self.length= length
        self.breadth= breadth 
        

    def area(self):
        return self.length*self.breadth
class Circle(Shape):
    def __init__(self, radius):
       
        self.radius= radius

    def area(self):
        return math.pi*self.radius*self.radius
        
length=int(input("Enter length for rectangle: "))
breadth= int(input("Enter breadth for rectangle: "))
radius= float(input("Enter radius for circle: "))


rect= Rectangle(length, breadth)
print(f"The area of rectangle is {rect.area()}")

circ= Circle(radius)
print(f"The area of circle is {circ.area()}")

