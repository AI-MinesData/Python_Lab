def calculate_frequency(sentence):
    
    frequency = {}
    for char in sentence:
        char = char.lower()
        if char in frequency:
            frequency[char] += 1    
        else:
            frequency[char] = 1
    return frequency

def main():    
    sentence = input("Please enter a sentence: ")    
    frequency = calculate_frequency(sentence)    
    print("\nCharacter frequency in the given sentence:")
    for char, count in frequency.items():
        print(f"'{char}': {count}")
main()

