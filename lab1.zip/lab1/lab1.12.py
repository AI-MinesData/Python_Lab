dictionary= {
    "x": 5,
    "y": 10,
    "z": 15
}

sum=0
for i in dictionary:
    sum+=dictionary[i]
print(f"The sum is {sum}")