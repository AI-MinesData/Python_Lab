dob= input("Enter dob")

print(dob[-4:])
